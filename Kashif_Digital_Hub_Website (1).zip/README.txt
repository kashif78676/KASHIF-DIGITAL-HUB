# KASHIF DIGITAL HUB Website

A responsive starter website for Amazon Virtual Assistant training and services.

## Included
- Home page
- Amazon VA course section
- Services section
- WhatsApp chat button
- Course inquiry form
- Contact information
- Mobile responsive design

## Contact used
Phone/WhatsApp: 0310-5200-350
Email: ka3067428@gmail.com

## How to use
Open `index.html` in a browser to preview the website.

For a real public website, upload these files to a web host such as GitHub Pages, Netlify, Vercel, or traditional hosting. A custom domain can then be connected.

Note: The WhatsApp button opens a direct WhatsApp conversation. The inquiry form opens the visitor's email app. A true live student chat system requires a backend/chat service and can be added later.
