document.querySelector('.menu').addEventListener('click',()=>{const n=document.querySelector('.nav nav');n.style.display=n.style.display==='flex'?'none':'flex';n.style.flexDirection='column';n.style.position='absolute';n.style.right='5%';n.style.top='70px';n.style.padding='18px';n.style.background='#fff';n.style.border='1px solid #eee';n.style.borderRadius='12px';});
document.getElementById('enrollForm').addEventListener('submit',function(e){
  e.preventDefault();
  const f=new FormData(this);
  const subject=encodeURIComponent('Amazon VA Course / Service Inquiry');
  const body=encodeURIComponent(
    `Name: ${f.get('name')}\nPhone/WhatsApp: ${f.get('phone')}\nEmail: ${f.get('email')}\nInterested In: ${f.get('interest')}\nMessage: ${f.get('message')||''}`
  );
  window.location.href=`mailto:ka3067428@gmail.com?subject=${subject}&body=${body}`;
});
